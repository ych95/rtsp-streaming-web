const Stream = require('node-rtsp-stream');

// RTSP 스트림 URL 목록
var rtspList = [
        { url: 'rtsp://210.99.70.120:1935/live/cctv001.stream', name: '세집매 삼거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv002.stream', name: '서부역 입구 삼거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv003.stream', name: '역말 오거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv004.stream', name: '천안로사거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv006.stream', name: '방죽안오거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv007.stream', name: '천안역' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv008.stream', name: '남부오거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv009.stream', name: '교보사거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv010.stream', name: '청삼교차로' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv011.stream', name: '신방삼거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv012.stream', name: '이마트 사거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv013.stream', name: '쌍용사거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv014.stream', name: '봉서사거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv015.stream', name: '구상골 사거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv016.stream', name: '인쇄창사거리' },
        { url: 'rtsp://210.99.70.120:1935/live/cctv017.stream', name: '부성초교사거리' }
];

var rtspListLength = rtspList.length;
for(var i=0; i<rtspListLength; i++){
        openStream(rtspList[i], i);
}

function openStream(obj, index){
var stream = new Stream({
        name: 'name',
        streamUrl : obj.url,
        wsPort: 10000 + index,
        ffmpegOptions: {
                '-stats': '',
                '-r': 30,
        }
});

obj.stream = stream;

}