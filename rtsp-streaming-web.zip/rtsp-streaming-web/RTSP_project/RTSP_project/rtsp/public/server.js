const express = require('express');
const path = require('path');
const app = express();

// 정적 파일 제공 경로 설정
app.use('/test1', express.static(path.join(__dirname, 'public', 'rtsp_test_1')));
app.use('/test2', express.static(path.join(__dirname, 'public', 'rtsp_test_2')));
app.use('/test3', express.static(path.join(__dirname, 'public', 'rtsp_test_3')));

// 라우트 설정
app.get('/test1', (req, res) => {
    res.sendFile(path.join(__dirname, 'rtsp_test_1', 'index.html'));
});

app.get('/test2', (req, res) => {
    res.sendFile(path.join(__dirname, 'rtsp_test_2', 'index.html'));
});

app.get('/test3', (req, res) => {
    res.sendFile(path.join(__dirname, 'rtsp_test_3', 'index.html'));
});


// 서버 시작
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
