# Node.js 와 FFmpeg를 활용한 RTSP 카메라 실시간 스트리밍 웹페이지

## 네트워크 통신 경로

> 1. 웹서버 실행 (server.js)
>> Express 서버가 시작되어 포트 3000에서 대기합니다.
>> 사용자가 /test1 경로로 접근할 때 index.html을 제공하도록 설정합니다.
```
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => {
        console.log(`Server is running on port ${PORT}`);
    });
```

> 2. RTSP 스트림 변환 및 WebSocket 서버 시작 (index.js)
>> RTSP 스트림 목록을 순회하여 각 스트림에 대해 웹 소켓 포트를 지정하고 FFmpeg 옵션을 적용하여 새로운 스트림 객체를 생성한 후, 해당 스트림 객체를 원래 스트림 정보 객체에 저장합니다    
WebSocket 서버가 포트 10000부터 시작하여 각 스트림에 대해 하나씩 생성됩니다.
```
streamUrls.forEach((streamInfo, index) => {
    new Stream({
        name: streamInfo.name,
        streamUrl: streamInfo.url,
        wsPort: 10000 + index, // 포트를 10000부터 시작하여 순차적으로 증가시킵니다.
        ffmpegOptions: {
            '-stats': '',
            '-r': 72
        }
    });
});
```

> 3. 클라이언트가 웹 페이지 요청 (index.html)
>> 사용자가 브라우저에서 http://<서버 IP>:3000/test1로 접근합니다.  
Express 서버는 index.html 파일을 클라이언트에 전송합니다.
```
app.get('/test1', (req, res) => {
    res.sendFile(path.join(__dirname, 'rtsp_test_1', 'index.html'));
});
```

> 4. 웹 페이지 로드 및 WebSocket 클라이언트 생성 (index.html)
>> 클라이언트의 브라우저는 index.html 파일을 로드하고, JavaScript 코드를 실행합니다.  
각 스트림에 대해 WebSocket 클라이언트를 생성하여 ws://192.168.100.200:3000 등의 주소로 연결합니다.
```
const client = new WebSocket(`ws://${window.location.hostname}:${10000 + streamInfo.index}`);
new jsmpeg(client, {
    canvas: canvas,
    autoplay: true,
    audio: false,
    loop: true
});
```

> 5. WebSocket을 통한 스트림 데이터 수신 및 렌더링 (index.html)
>> WebSocket 클라이언트는 서버와 연결되어 스트림 데이터를 수신합니다.  
jsmpeg 라이브러리를 통해 스트림 데이터를 canvas에 렌더링합니다.
```
new jsmpeg(client, {
    canvas: canvas,
    autoplay: true,
    audio: false,
    loop: true
});
```

