const Stream = require('node-rtsp-stream');

// RTSP 스트림 URL 목록
var rtspList = [
    { url: 'rtsp://admin:123456@125.139.27.246:10004/stream1', name: '전북 정읍 새암1' },
    { url: 'rtsp://admin:123456@125.139.27.246:10015/stream1', name: '전북 정읍 새암2' },
    { url: 'rtsp://admin:123456@59.2.131.14:10005/stream1', name: '전북 정읍 각시다리' },
    { url: 'rtsp://admin:!qaz2wsx3edc@211.223.13.174:28554/profile2/media.smp', name: '광주 비아5일장' },
    { url: 'rtsp://admin:abcd1234@220.80.98.160:30554/Streaming/Channels/102?transportmode=unicast&profile=Profile_2', name: '광주 광산구청' },
    { url: 'rtsp://admin:123456@118.40.101.177:8021/stream1', name: '광주 송정역' },
    { url: 'rtsp://admin:!qaz2wsx@121.148.240.57:1554/sub', name: '광주 하남3지구' },
    { url: 'rtsp://admin:admin@210.223.214.45:8211/stream2', name: '충북 제천 하소동' },
    { url: 'rtsp://admin:123456@121.159.253.176:8556/stream1', name: '충남 태안 남문 동문' },
    { url: 'rtsp://admin:123456@121.159.253.176:8558/stream1', name: '충남 태안 남문 서문' },
    { url: 'rtsp://admin:123456@121.159.253.176:8553/stream1', name: '충남 태안 남문 북문' },
    { url: 'rtsp://admin:123456@121.159.253.176:8551/stream1', name: '충남 태안 남문 사전1' },
];

var rtspListLength = rtspList.length;
for(var i=0; i<rtspListLength; i++){
        openStream(rtspList[i], i);
}

function openStream(obj, index){
    var stream = new Stream({
            name: 'name',
            streamUrl : obj.url,
            wsPort: 10012 + index,
            ffmpegOptions: {
                    '-stats': '',
                    '-r': 30,
            }
    });

    obj.stream = stream;

}