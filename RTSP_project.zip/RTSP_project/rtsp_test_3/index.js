const Stream = require('node-rtsp-stream');

// RTSP 스트림 URL 목록
var rtspList = [
    { url: 'rtsp://admin:123456@117.110.13.243:8232/stream1', name: '충남 태안 버스터미널' },
    { url: 'rtsp://admin:123456@221.160.237.76:8554/stream1', name: '충남 금산 구법원' },
    { url: 'rtsp://admin:123456@116.125.208.19:8554/stream1', name: '충남 서산 번화로' },
    { url: 'rtsp://admin:123456@121.182.33.49:8251/stream1', name: '경북 고령 대가야' },
    { url: 'rtsp://admin:123456@121.182.33.49:8252/stream1', name: '경북 고령 대가야 사전1' },
    { url: 'rtsp://admin:123456@121.182.33.49:8253/stream1', name: '경북 고령 대가야 사전2' },
    { url: 'rtsp://admin:@iksan2022!@119.206.37.91:8511/profile2/media.smp', name: '익산 영등2동 입차' },
    { url: 'rtsp://admin:@iksan2022!@119.206.37.91:8515/profile2/media.smp', name: '익산 영등2동 출차' },
    { url: 'rtsp://admin:123456@59.1.156.89:8232/stream1', name: '익산 모현3동 입차' },
    { url: 'rtsp://admin:123456@121.186.222.217:8554/stream1', name: '익산남부주차타워 입차' },
    { url: 'rtsp://admin:123456@121.186.222.217:8555/stream1', name: '익산남부주차타워 출차' }
];

var rtspListLength = rtspList.length;
for(var i=0; i<rtspListLength; i++){
        openStream(rtspList[i], i);
}

function openStream(obj, index){
    var stream = new Stream({
            name: 'name',
            streamUrl : obj.url,
            wsPort: 10025 + index,
            ffmpegOptions: {
                    '-stats': '',
                    '-r': 30,
            }
    });

    obj.stream = stream;

}
